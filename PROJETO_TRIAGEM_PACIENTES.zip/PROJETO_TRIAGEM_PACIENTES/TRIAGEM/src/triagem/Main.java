/**
 * Pacote que contém a classe principal e as classes relacionadas ao sistema de triagem.
 */
package triagem;

import Pessoa.Colaborador;
import Pessoa.Paciente;
import java.util.Scanner;

/**
 * Classe principal que contém o método main para iniciar o sistema de triagem.
 */
public class Main {

    /**
     * Método principal que inicia o sistema de triagem.
     *
     * @param args Os argumentos de linha de comando (não são usados neste sistema).
     */
    public static void main(String[] args) {
        Sistema sistema = new Sistema();
        Scanner scanner = new Scanner(System.in);
        Login login = new Login();

        int tentativasRestantes = 3; // Número de tentativas restantes para login

        System.out.println("=============================================");
        System.out.println("Bem vindo ao Sistema de Triagem WS Hospitalar");
        System.out.println("================ Login ======================");

        // Loop para controle das tentativas de login
        while (tentativasRestantes > 0) {
            System.out.print("Usuário: ");
            String usuario = scanner.nextLine();
            System.out.print("Senha: ");
            String senha = scanner.nextLine();

            if (login.validarLogin(usuario, senha)) {
                // Login bem-sucedido, executar opções específicas para cada tipo de usuário
                if (usuario.equalsIgnoreCase("enfermeiro")) {
                    System.out.println("Login do Enfermeiro realizado com sucesso!");
                    executarOpcoesEnfermeiro(sistema, scanner);
                } else if (usuario.equalsIgnoreCase("medico")) {
                    System.out.println("Login do Médico realizado com sucesso!");
                    executarOpcoesMedico(sistema, scanner);
                } else if (usuario.equalsIgnoreCase("administrador")) {
                    System.out.println("Login do Administrador realizado com sucesso!");
                    executarOpcoesAdministrador(sistema, scanner);
                }
                //break; // Sai do loop de tentativas em caso de login bem-sucedido
             } else {
                tentativasRestantes--;
                if (tentativasRestantes > 0) {
                    System.out.println("Login inválido. Tentativas restantes: " + tentativasRestantes);
                    if (tentativasRestantes == 2) {
                        System.out.println("Dica: Tente novamente com letras maiúsculas e minúsculas corretas.");
                    } else if (tentativasRestantes == 1) {
                        System.out.println("Dica: Verifique se a senha contém números e caracteres especiais.");
                    }
                } else {
                    System.out.println("Número de tentativas excedido. Encerrando o sistema.");
                }
            }
            System.out.print("Deseja encerrar o sistema? (s/n) ");
            String fimSistema = scanner.nextLine();
            if(fimSistema.equals("s") || fimSistema.equals( "S")){
                break;
            }
        }

        scanner.close();
    }


    // Métodos para as opções do Enfermeiro

    /**
     * Executa as opções disponíveis para o Enfermeiro no sistema.
     *
     * @param sistema O sistema de triagem.
     * @param scanner O scanner para leitura de entrada do usuário.
     */
    private static void executarOpcoesEnfermeiro(Sistema sistema, Scanner scanner) {
        System.out.println("============================================= ");
        System.out.println("=========== Opções do Enfermeiro ============ ");
        System.out.println("============================================= ");
        int opcao;
        do {
            System.out.println("******************************************");
            System.out.println("1. Triagem de Pacientes");
            System.out.println("2. Atualizar Status de Pacientes");
            System.out.println("3. Imprimir Dados dos Pacientes");
            System.out.println("4. Imprimir Relatório de Estatísticas");
            System.out.println("5. Encerrar Sessão de Enfermeiro");
            System.out.println("******************************************");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine(); // Consumir a quebra de linha após ler o número.

            switch (opcao) {
                case 1:
                    // Triagem de Pacientes
                    if (sistema.getPacientes().isEmpty()) {
                        System.out.println("Não há pacientes cadastrados no sistema.");
                    } else {
                        System.out.print("Digite o ID do paciente que deseja triar: ");
                        int idPaciente = scanner.nextInt();
                        scanner.nextLine();
                        Paciente pacienteSelecionado = sistema.buscarPacientePorId(idPaciente);
                        if (pacienteSelecionado == null) {
                            System.out.println("Paciente não encontrado.");
                        } else {
                            System.out.print("Digite a comorbidade (ou 'nenhuma' se não houver): ");
                            String comorbidade = scanner.nextLine();
                            System.out.print("Digite o status do paciente (recuperado, óbito, internado, isolamento): ");
                            String status = scanner.nextLine();
                            pacienteSelecionado.setComorbidade(comorbidade);
                            pacienteSelecionado.setStatus(status);
                            System.out.println("Triagem do paciente realizada com sucesso.");
                        }
                    }
                    break;
                case 2:
                    // Atualizar Status de Pacientes
                    if (sistema.getPacientes().isEmpty()) {
                        System.out.println("Não há pacientes cadastrados no sistema.");
                    } else {
                        System.out.print("Digite o ID do paciente que deseja atualizar o status: ");
                        int idPaciente = scanner.nextInt();
                        scanner.nextLine();
                        Paciente pacienteSelecionado = sistema.buscarPacientePorId(idPaciente);
                        if (pacienteSelecionado == null) {
                            System.out.println("Paciente não encontrado.");
                        } else {
                            System.out.print("Digite o novo status do paciente: ");
                            String novoStatus = scanner.nextLine();
                            pacienteSelecionado.setStatus(novoStatus);
                            System.out.println("Status do paciente atualizado com sucesso.");
                        }
                    }
                    break;
                case 3:
                    // Imprimir Dados dos Pacientes
                    if (sistema.getPacientes().isEmpty()) {
                        System.out.println("Não há pacientes cadastrados no sistema.");
                    } else {
                        sistema.imprimirDadosPacientes();
                    }
                    break;
                case 4:
                    // Imprimir Relatório de Estatísticas
                    if (sistema.getPacientes().isEmpty()) {
                        System.out.println("Não há pacientes cadastrados no sistema.");
                    } else {
                        sistema.imprimirRelatorioEstatisticas();
                    }
                    break;
                case 5:
                    // Encerrar Sessão de Enfermeiro
                    System.out.println("Sessão do enfermeiro encerrada.");
                    return;
                default:
                    System.out.println("Opção inválida. Digite novamente.");
            }
        } while (opcao != 5);
    }

    // Continuação dos métodos para as opções do Médico

    /**
     * Executa as opções disponíveis para o Médico no sistema.
     *
     * @param sistema O sistema de triagem.
     * @param scanner O scanner para leitura de entrada do usuário.
     */
    private static void executarOpcoesMedico(Sistema sistema, Scanner scanner) {
        System.out.println("============================================= ");
        System.out.println("============= Opções do Médico ============== ");
        System.out.println("============================================= ");
        int opcao;
        do {
            System.out.println("******************************************");
            System.out.println("1. Atualizar Status de Pacientes");
            System.out.println("2. Imprimir Dados dos Pacientes");
            System.out.println("3. Imprimir Relatório de Estatísticas");
            System.out.println("4. Encerrar Sessão de Médico");
            System.out.println("******************************************");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine(); // Consumir a quebra de linha após ler o número.

            switch (opcao) {
                case 1:
                    // Atualizar Status de Pacientes
                    if (sistema.getPacientes().isEmpty()) {
                        System.out.println("Não há pacientes cadastrados no sistema.");
                    } else {
                        System.out.print("Digite o ID do paciente que deseja atualizar o status: ");
                        int idPaciente = scanner.nextInt();
                        scanner.nextLine();
                        Paciente pacienteSelecionado = sistema.buscarPacientePorId(idPaciente);
                        if (pacienteSelecionado == null) {
                            System.out.println("Paciente não encontrado.");
                        } else {
                            System.out.print("Digite o novo status do paciente: ");
                            String novoStatus = scanner.nextLine();
                            pacienteSelecionado.setStatus(novoStatus);
                            System.out.println("Status do paciente atualizado com sucesso.");
                        }
                    }
                    break;
                case 2:
                    // Imprimir Dados dos Pacientes
                    if (sistema.getPacientes().isEmpty()) {
                        System.out.println("Não há pacientes cadastrados no sistema.");
                    } else {
                        sistema.imprimirDadosPacientes();
                    }
                    break;
                case 3:
                    // Imprimir Relatório de Estatísticas
                    if (sistema.getPacientes().isEmpty()) {
                        System.out.println("Não há pacientes cadastrados no sistema.");
                    } else {
                        sistema.imprimirRelatorioEstatisticas();
                    }
                    break;
                case 4:
                    // Encerrar Sessão de Médico
                    System.out.println("Sessão do médico encerrada.");
                    return;
                default:
                    System.out.println("Opção inválida. Digite novamente.");
            }
        } while (opcao != 4);
    }

    // Métodos para as opções do Administrador

    /**
     * Executa as opções disponíveis para o Administrador no sistema.
     *
     * @param sistema O sistema de triagem.
     * @param scanner O scanner para leitura de entrada do usuário.
     */
    private static void executarOpcoesAdministrador(Sistema sistema, Scanner scanner) {
        System.out.println("============================================");
        System.out.println("========== Opções do Administrador =========");
        System.out.println("============================================");
        int opcao;
        do {
            System.out.println("****************************************");
            System.out.println("1. Cadastrar Colaborador");
            System.out.println("2. Alterar Colaborador");
            System.out.println("3. Excluir Colaborador");
            System.out.println("4. Cadastrar Paciente");
            System.out.println("5. Alterar Paciente");
            System.out.println("6. Excluir Paciente");
            System.out.println("7. Atualizar Status do Paciente");
            System.out.println("8. Imprimir Dados dos Pacientes");
            System.out.println("9. Imprimir Relatório de Estatísticas");
            System.out.println("10. Ordenar Pacientes por Idade");
            System.out.println("11. Ordenar Pacientes por Comorbidade");
            System.out.println("12. Ordenar Pacientes por Nome");
            System.out.println("13. Ordenar Pacientes por Sobrenome");
            System.out.println("14. Imprimir Pacientes Ordenados");
            System.out.println("15. Encerrar o Sistema");
            System.out.println("****************************************");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine(); // Consumir a quebra de linha após ler o número.

            switch (opcao) {
                case 1:
                    // Cadastrar Colaborador
                    if (Sistema.MAX_COLABORADORES.length > 100) {
                        System.out.println("Limite máximo de colaboradores atingido. Não é possível cadastrar mais colaboradores.");
                    } else {
                        sistema.cadastrarColaborador();
                    }
                    break;
                case 2:
                    // Alterar Colaborador
                    if (Sistema.MAX_COLABORADORES[0] == null) {
                        System.out.println("Não há colaboradores cadastrados no sistema.");
                    } else {
                        System.out.print("Informe o ID do colaborador a ser alterado: ");
                        int idColaboradorAlterar = scanner.nextInt();
                        scanner.nextLine(); // Consumir a quebra de linha após ler o número

                        // Verificar se o colaborador com o ID informado existe
                        boolean colaboradorEncontrado = false;
                        for (Colaborador colaborador : sistema.MAX_COLABORADORES) {
                            if (colaborador != null && colaborador.getId() == idColaboradorAlterar) {
                                colaboradorEncontrado = true;
                                break;
                            }
                        }

                        if (!colaboradorEncontrado) {
                            System.out.println("Colaborador não encontrado.");
                        } else {
                            Colaborador colaboradorAlterado = new Colaborador(); // Crie uma nova instância de Colaborador para armazenar os novos dados

                            System.out.print("Digite o nome do colaborador: ");
                            String nome = scanner.nextLine();
                            colaboradorAlterado.setNome(nome);

                            System.out.print("Digite o Cargo do Colaborador: ");
                            String cargo = scanner.nextLine();
                            colaboradorAlterado.setCargo(cargo);

                            System.out.print("Digite o Email do Colaborador: ");
                            String email = scanner.nextLine();
                            colaboradorAlterado.setEmail(email);

                            System.out.print("Digite o Telefone do Colaborador: ");
                            String telefone = scanner.nextLine();
                            colaboradorAlterado.setTelefone(telefone);

                            sistema.alterarColaborador(idColaboradorAlterar, colaboradorAlterado);
                        }
                    }
                    break;
                case 3:
                    // Excluir Colaborador
                    if (Sistema.MAX_COLABORADORES[0] == null) {
                        System.out.println("Não há colaboradores cadastrados no sistema.");
                    } else {
                        int idColaboradorExcluir = sistema.lerIdColaborador(scanner); // Método para ler o ID do colaborador a ser excluído
                        sistema.excluirColaborador(idColaboradorExcluir);
                    }
                    break;
                case 4:
                    Paciente novoPaciente = new Paciente(); // Se necessário, crie um objeto Paciente vazio
                    sistema.cadastrarPaciente(novoPaciente);
                    break;
                case 5:
                    // Alterar Paciente
                    if (sistema.getPacientes().isEmpty()) {
                        System.out.println("Não há pacientes cadastrados no sistema.");
                    } else {
                        System.out.print("Informe o ID do paciente a ser alterado: ");
                        int idPacienteAlterar = scanner.nextInt();
                        scanner.nextLine(); // Consumir a quebra de linha após ler o número

                        // Verificar se o paciente com o ID informado existe
                        boolean pacienteEncontrado = false;
                        for (Paciente paciente : sistema.getPacientes()) {
                            if (paciente.getId() == idPacienteAlterar) {
                                pacienteEncontrado = true;
                                break;
                            }
                        }

                        if (!pacienteEncontrado) {
                            System.out.println("Paciente não encontrado.");
                        } else {
                            System.out.print("Digite o novo nome do paciente: ");
                            String novoNome = scanner.nextLine();

                            System.out.print("Digite o novo sobrenome do paciente: ");
                            String novoSobrenome = scanner.nextLine();

                            System.out.print("Digite a nova idade do paciente: ");
                            int novaIdade = scanner.nextInt();
                            scanner.nextLine(); // Consumir a quebra de linha após ler o número
                                                        System.out.print("O paciente possui comorbidade? (s/n): ");
                            String comorbidadeInput = scanner.nextLine();
                            boolean novaComorbidade = comorbidadeInput.equalsIgnoreCase("s");

                            // Encontrar o paciente a ser alterado na lista de pacientes
                            Paciente pacienteAlterado = null;
                            for (Paciente paciente : sistema.getPacientes()) {
                                if (paciente.getId() == idPacienteAlterar) {
                                    pacienteAlterado = paciente;
                                    break;
                                }
                            }

                            // Atualizar os dados do paciente diretamente no objeto encontrado
                            pacienteAlterado.setNome(novoNome);
                            pacienteAlterado.setSobrenome(novoSobrenome);
                            pacienteAlterado.setIdade(novaIdade);
                            pacienteAlterado.setComorbidade(novaComorbidade);

                            System.out.println("Paciente alterado com sucesso!");
                        }
                    }
                    break;
                case 6:
                    // Excluir Paciente
                    if (sistema.getPacientes().isEmpty()) {
                        System.out.println("Não há pacientes cadastrados no sistema.");
                    } else {
                        int idPacienteExcluir = sistema.lerIdPaciente(scanner); // Método para ler o ID do paciente a ser excluído
                        sistema.excluirPaciente(idPacienteExcluir);
                    }
                    break;
                case 7:
                    // Atualizar Status do Paciente
                    if (sistema.getPacientes().isEmpty()) {
                        System.out.println("Não há pacientes cadastrados no sistema.");
                    } else {
                        int idPacienteAtualizarStatus = sistema.lerIdPaciente(scanner); // Método para ler o ID do paciente a ser atualizado
                        String novoStatus = sistema.lerNovoStatus(scanner); // Método para ler o novo status do paciente
                        sistema.atualizarStatusPaciente(idPacienteAtualizarStatus, novoStatus);
                    }
                    break;
                case 8:
                    // Imprimir Dados dos Pacientes
                    if (sistema.getPacientes().isEmpty()) {
                        System.out.println("Não há pacientes cadastrados no sistema.");
                    } else {
                        sistema.imprimirDadosPacientes();
                    }
                    break;
                case 9:
                    // Imprimir Relatório de Estatísticas
                    if (sistema.getPacientes().isEmpty()) {
                        System.out.println("Não há pacientes cadastrados no sistema.");
                    } else {
                        sistema.imprimirRelatorioEstatisticas();
                    }
                    break;
                case 10:
                    // Ordenar Pacientes por Idade
                    if (sistema.getPacientes().isEmpty()) {
                        System.out.println("Não há pacientes cadastrados no sistema.");
                    } else {
                        sistema.ordenarPacientesPorIdade();
                        sistema.imprimirPacientesOrdenados();
                    }
                    break;
                case 11:
                    // Ordenar Pacientes por Comorbidade
                    if (sistema.getPacientes().isEmpty()) {
                        System.out.println("Não há pacientes cadastrados no sistema.");
                    } else {
                        sistema.ordenarPacientesPorComorbidade();
                        sistema.imprimirPacientesOrdenados();
                    }
                    break;
                case 12:
                    // Ordenar Pacientes por Nome
                    if (sistema.getPacientes().isEmpty()) {
                        System.out.println("Não há pacientes cadastrados no sistema.");
                    } else {
                        sistema.ordenarPacientesPorNome();
                        sistema.imprimirPacientesOrdenados();
                    }
                    break;
                case 13:
                    // Ordenar Pacientes por Sobrenome
                    if (sistema.getPacientes().isEmpty()) {
                        System.out.println("Não há pacientes cadastrados no sistema.");
                    } else {
                        sistema.ordenarPacientesPorSobrenome();
                        sistema.imprimirPacientesOrdenados();
                    }
                    break;
                case 14:
                    // Imprimir Pacientes Ordenados
                    if (sistema.getPacientes().isEmpty()) {
                        System.out.println("Não há pacientes cadastrados no sistema.");
                    } else {
                        sistema.imprimirPacientesOrdenados();
                    }
                    break;
                case 15:
                    // Encerrar o Sistema
                    System.out.println("Sessão do administrador encerrada.");
                    return;
                default:
                    System.out.println("Opção inválida. Digite novamente.");
            }
        } while (opcao != 15);
    }
}

