package triagem;

import Pessoa.Colaborador;
import Pessoa.Paciente;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

/**
 * Classe que representa o sistema de triagem.
 */
public class Sistema {
    static Colaborador[] MAX_COLABORADORES = new Colaborador[100];
    private List<Paciente> pacientes = new ArrayList<>();
    Scanner scanner = new Scanner(System.in);

    // Construtor da classe Sistema
    public Sistema() {
        this.pacientes = new ArrayList<>();
    }

    // Altere a assinatura do método para que ele retorne a lista de pacientes
    public List<Paciente> getPacientes() {
        return pacientes;
    }

    // Métodos para cadastrar, alterar e excluir colaboradores

    /**
     * Cadastra um novo colaborador no sistema.
     *
     * @param colaborador O colaborador a ser cadastrado.
     */
    public void cadastrarColaborador() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o Id do colaborador: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Limpar a quebra de linha deixada pelo nextInt()

        // Verificar se o ID do colaborador já existe na lista de colaboradores
        boolean idExistente = false;
        for (Colaborador colaborador : Sistema.MAX_COLABORADORES) {
            if (colaborador != null && colaborador.getId() == id) {
                idExistente = true;
                break;
            }
        }

        if (idExistente) {
            System.out.println("Já existe um colaborador cadastrado com o mesmo ID. Cadastro não realizado.");
        } else {
            System.out.print("Digite o nome do colaborador: ");
            String nome = scanner.nextLine();

            System.out.print("Digite o Cargo do Colaborador: ");
            String cargo = scanner.nextLine();

            System.out.print("Digite o Email do Colaborador: ");
            String email = scanner.nextLine();

            System.out.print("Digite o Telefone do Colaborador: ");
            String telefone = scanner.nextLine();

            Colaborador colaborador = new Colaborador(id, nome, cargo, email, telefone);
            for (int i = 0; i < Sistema.MAX_COLABORADORES.length; i++) {
                if (Sistema.MAX_COLABORADORES[i] == null) {
                    Sistema.MAX_COLABORADORES[i] = colaborador;
                    System.out.println("Colaborador cadastrado com sucesso!");
                    return; // Sai do método após cadastrar o colaborador
                }
            }
        }
    }

    /**
     * Altera os dados de um colaborador no sistema.
     *
     * @param id             O ID do colaborador a ser alterado.
     * @param novoColaborador O novo colaborador com os dados atualizados.
     */
    public void alterarColaborador(int id, Colaborador novoColaborador) {
        for (int i = 0; i < MAX_COLABORADORES.length; i++) {
            Colaborador colaborador = MAX_COLABORADORES[i];
            if (colaborador != null && colaborador.getId() == id) {
                MAX_COLABORADORES[i] = novoColaborador;
                System.out.println("Colaborador alterado com sucesso!");
                return;
            }
        }
        System.out.println("Colaborador não encontrado.");
    }

    /**
     * Exclui um colaborador do sistema.
     *
     * @param id O ID do colaborador a ser excluído.
     */
    public void excluirColaborador(int id) {
        for (int i = 0; i < MAX_COLABORADORES.length; i++) {
            Colaborador colaborador = MAX_COLABORADORES[i];
            if (colaborador != null && colaborador.getId() == id) {
                MAX_COLABORADORES[i] = null;
                System.out.println("Colaborador excluído com sucesso!");
                return;
            }
        }
        System.out.println("Colaborador não encontrado.");
    }

    // Métodos para cadastrar, alterar e excluir pacientes

    /**
     * Cadastra um novo paciente no sistema.
     *
     * @param paciente O paciente a ser cadastrado.
     */
    public void cadastrarPaciente(Paciente paciente) {
        System.out.print("Digite o ID do paciente: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consumir a quebra de linha após ler o número

        // Verificar se o ID do paciente já existe na lista de pacientes
        boolean idExistente = false;
        for (Paciente p : pacientes) {
            if (p.getId() == id) {
                idExistente = true;
                break;
            }
        }

        if (idExistente) {
            System.out.println("Já existe um paciente cadastrado com o mesmo ID. Cadastro não realizado.");
        } else {
            System.out.print("Digite o nome do paciente: ");
            String nome = scanner.nextLine();

            System.out.print("Digite o sobrenome do paciente: ");
            String sobrenome = scanner.nextLine();

            System.out.print("Digite a idade do paciente: ");
            int idade = scanner.nextInt();
            scanner.nextLine(); // Consumir a quebra de linha após ler o número

            System.out.print("O paciente possui comorbidade? (s/n): ");
            String comorbidadeInput = scanner.nextLine();
            boolean comorbidade = comorbidadeInput.equalsIgnoreCase("s");

            // Criar uma nova instância de Paciente com os dados lidos
            Paciente novoPaciente = new Paciente(nome, sobrenome, idade, comorbidade);
            novoPaciente.setId(id);

            pacientes.add(novoPaciente);
            System.out.println("Paciente cadastrado com sucesso!");
        }
    }

    /**
     * Altera os dados de um paciente no sistema.
     *
     * @param id          O ID do paciente a ser alterado.
     * @param novoPaciente O novo paciente com os dados atualizados.
     */
    public void alterarPaciente(int id, Paciente novoPaciente) {
        for (int i = 0; i < pacientes.size(); i++) {
            Paciente paciente = pacientes.get(i);
            if (paciente.getId() == id) {
                pacientes.set(i, novoPaciente);
                System.out.println("Paciente alterado com sucesso!");
                return;
            }
        }
        System.out.println("Paciente não encontrado.");
    }

    /**
     * Exclui um paciente do sistema.
     *
     * @param id O ID do paciente a ser excluído.
     */
    public void excluirPaciente(int id) {
        pacientes.removeIf(paciente -> paciente.getId() == id);
        System.out.println("Paciente excluído com sucesso!");
    }

    // Método para atualizar o status dos pacientes

    /**
     * Atualiza o status de um paciente no sistema.
     *
     * @param id         O ID do paciente a ser atualizado.
     * @param novoStatus O novo status do paciente.
     */
    public void atualizarStatusPaciente(int id, String novoStatus) {
        for (Paciente paciente : pacientes) {
            if (paciente.getId() == id) {
                paciente.setStatus(novoStatus);
                System.out.println("Status do paciente atualizado com sucesso!");
                return;
            }
        }
        System.out.println("Paciente não encontrado.");
    }

    // Método para imprimir dados dos pacientes e relatórios de estatísticas de doenças

    /**
     * Imprime os dados de todos os pacientes cadastrados no sistema.
     */
    public void imprimirDadosPacientes() {
        System.out.println("==== Dados dos Pacientes ====");
        for (Paciente paciente : pacientes) {
            System.out.println(paciente);
        }
    }

    /**
     * Imprime o relatório de estatísticas sobre os pacientes cadastrados.
     * O relatório inclui o total de pacientes, o total de pacientes com comorbidades e o total de pacientes sem comorbidades.
     */
    public void imprimirRelatorioEstatisticas() {
        int totalComorbidades = 0;
        for (Paciente paciente : pacientes) {
            if (paciente.isComorbidade()) {
                totalComorbidades++;
            }
        }
        System.out.println("==== Relatório de Estatísticas ====");
        System.out.println("Total de Pacientes: " + pacientes.size());
        System.out.println("Pacientes com Comorbidades: " + totalComorbidades);
        System.out.println("Pacientes sem Comorbidades: " + (pacientes.size() - totalComorbidades));
    }

    // Métodos para ordenar a lista de pacientes usando a classe Collections.sort() com diferentes comparators

    /**
     * Ordena a lista de pacientes por idade.
     */
    public void ordenarPacientesPorIdade() {
        Collections.sort(pacientes, Comparator.comparingInt(Paciente::getIdade));
    }

    /**
     * Ordena a lista de pacientes por comorbidade.
     */
    public void ordenarPacientesPorComorbidade() {
        Collections.sort(pacientes, Comparator.comparing(Paciente::isComorbidade));
    }

    /**
     * Ordena a lista de pacientes por nome.
     */
    public void ordenarPacientesPorNome() {
        Collections.sort(pacientes, Comparator.comparing(Paciente::getNome));
    }

    /**
     * Ordena a lista de pacientes por sobrenome.
     */
    public void ordenarPacientesPorSobrenome() {
        Collections.sort(pacientes, Comparator.comparing(Paciente::getSobrenome));
    }

    /**
     * Imprime a lista de pacientes ordenada.
     */
    public void imprimirPacientesOrdenados() {
        System.out.println("==== Pacientes Ordenados ====");
        for (Paciente paciente : pacientes) {
            System.out.println(paciente);
        }
    }

    // Método para buscar paciente por ID
    public Paciente buscarPacientePorId(int idPaciente) {
        for (Paciente paciente : pacientes) {
            if (paciente.getId() == idPaciente) {
                return paciente;
            }
        }
        return null; // Retorna null caso não encontre o paciente com o ID informado
    }

    /**
     * Realiza a leitura do ID de um colaborador a ser alterado ou excluído.
     *
     * @param scanner O scanner para leitura de dados do usuário.
     * @return O ID do colaborador informado pelo usuário.
     */
    int lerIdColaborador(Scanner scanner) {
        System.out.print("Informe o ID do colaborador: ");
        return scanner.nextInt();
    }

    /**
     * Realiza a leitura do ID de um paciente a ser alterado, excluído ou atualizado o status.
     *
     * @param scanner O scanner para leitura de dados do usuário.
     * @return O ID do paciente informado pelo usuário.
     */
    int lerIdPaciente(Scanner scanner) {
        System.out.print("Informe o ID do paciente: ");
        return scanner.nextInt();
    }

    /**
     * Realiza a leitura do novo status de um paciente a ser atualizado.
     *
     * @param scanner O scanner para leitura de dados do usuário.
     * @return O novo status informado pelo usuário.
     */
    String lerNovoStatus(Scanner scanner) {
        System.out.print("Informe o novo status do paciente: ");
        scanner.nextLine(); // Consumir a quebra de linha após ler o número.
        return scanner.nextLine();
    }
}
