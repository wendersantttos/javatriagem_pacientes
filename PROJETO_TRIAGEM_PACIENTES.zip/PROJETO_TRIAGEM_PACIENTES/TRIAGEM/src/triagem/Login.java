/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package triagem;

import java.util.Scanner;

/**
 *
 * @author Wender Santos
 */
public class Login {
    // Método para validar o login do usuário
    public boolean validarLogin(String usuario, String senha) {
        // Verificar o tipo de usuário e realizar o login
        if (usuario.equalsIgnoreCase("enfermeiro") && senha.equals("enf123")) {
            return true;
        } else if (usuario.equalsIgnoreCase("medico") && senha.equals("med123")) {
            return true;
        } else if (usuario.equalsIgnoreCase("administrador") && senha.equals("admin123")) {
            return true;
        } else {
            return false;
        }
    }
}
