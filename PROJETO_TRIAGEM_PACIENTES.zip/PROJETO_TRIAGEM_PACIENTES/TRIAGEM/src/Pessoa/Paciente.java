package Pessoa;

import java.util.Comparator;

/**
 * Classe que representa um Paciente no sistema.
 * Implementa a interface Comparator para realizar comparações por diferentes atributos.
 */
public class Paciente implements Comparator<Paciente> {
    private int id;
    private String nome;
    private String sobrenome;
    private int idade;
    private boolean comorbidade;
    private String status;
    private static int totalPacientesEncapsulamento = 0;
    protected static int totalPacientesProtegido = 0;

    /**
     * Construtor padrão da classe Paciente.
     * Incrementa os contadores de pacientes encapsulados e protegidos.
     */
    public Paciente() {
        totalPacientesEncapsulamento = totalPacientesEncapsulamento + 1;
        totalPacientesProtegido = totalPacientesProtegido + 1;
    }

    /**
     * Construtor da classe Paciente que permite definir os atributos iniciais do paciente.
     *
     * @param nome        O nome do paciente.
     * @param sobrenome   O sobrenome do paciente.
     * @param idade       A idade do paciente.
     * @param comorbidade Indica se o paciente possui comorbidade (true ou false).
     */
    public Paciente(String nome, String sobrenome, int idade, boolean comorbidade) {
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.idade = idade;
        this.comorbidade = comorbidade;
        this.status = "Não triado";
        totalPacientesEncapsulamento = totalPacientesEncapsulamento + 1;
        totalPacientesProtegido = totalPacientesProtegido + 1;
    }

    // Getters e Setters (não é necessário documentar os getters e setters JavaDoc)

    /**
     * Obtém o total de pacientes criados usando encapsulamento.
     *
     * @return O total de pacientes criados usando encapsulamento.
     */
    public static int getTotalPacientesEncapsulamento() {
        return totalPacientesEncapsulamento;
    }

    /**
     * Obtém o total de pacientes criados usando proteção.
     *
     * @return O total de pacientes criados usando proteção.
     */
    public static int getTotalPacientesProtegido() {
        return totalPacientesProtegido;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public boolean isComorbidade() {
        return comorbidade;
    }

    public void setComorbidade(boolean comorbidade) {
        this.comorbidade = comorbidade;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // Implementação do método compare da interface Comparator para ordenar por Nome e Sobrenome

    @Override
    public int compare(Paciente p1, Paciente p2) {
        // Implementação da comparação por diferentes atributos (Idade, Comorbidade, Nome e Sobrenome).
        // Aqui, por simplicidade, vamos comparar por nome e, em caso de empate, por sobrenome.
        int nomeComparison = p1.nome.compareTo(p2.nome);
        if (nomeComparison != 0) {
            return nomeComparison;
        }
        return p1.sobrenome.compareTo(p2.sobrenome);
    }

    /**
     * Retorna uma representação em String do Paciente, incluindo todos os seus atributos.
     *
     * @return Uma String que representa o Paciente.
     */
    @Override
    public String toString() {
        return "ID: " + id + ", Nome: " + nome + " " + sobrenome + ", Idade: " + idade + ", Comorbidade: " + comorbidade + ", Status: " + status;
    }

    public void setComorbidade(String comorbidade) {
        throw new UnsupportedOperationException("Not supported yet."); // Gerado a partir de nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
