/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pessoa;

/**
 *
 * @author Wender Santos
 */
public class Funcionario extends Colaborador  {
    
    public Funcionario(int id, String nome, String cargo, String email, String telefone) {
        super(id, nome, cargo, email, telefone);
    } 

    @Override
    public String toString() {
        return "Funcionario{" + '}';
    }
    
    
}
