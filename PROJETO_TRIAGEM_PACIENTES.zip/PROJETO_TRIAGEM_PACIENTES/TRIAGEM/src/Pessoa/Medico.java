package Pessoa;

/**
 * Classe que representa um Médico, que é um tipo de Colaborador.
 * Herda os atributos e métodos da classe Colaborador.
 */
public class Medico extends Colaborador {
    private String especialidade;

    /**
     * Construtor que inicializa um Médico com todos os atributos.
     *
     * @param id            O ID do Médico.
     * @param nome          O nome do Médico.
     * @param cargo         O cargo do Médico.
     * @param email         O email do Médico.
     * @param telefone      O telefone do Médico.
     * @param especialidade A especialidade do Médico.
     */
    public Medico(int id, String nome, String cargo, String email, String telefone, String especialidade) {
        super(id, nome, cargo, email, telefone);
        this.especialidade = especialidade;
    }

    // Getters e Setters (não é necessário documentar os getters e setters JavaDoc)

    /**
     * Obtém a especialidade do Médico.
     *
     * @return A especialidade do Médico.
     */
    public String getEspecialidade() {
        return especialidade;
    }

    /**
     * Define a especialidade do Médico.
     *
     * @param especialidade A especialidade do Médico a ser definida.
     */
    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }

    /**
     * Retorna uma representação em String do Médico, incluindo seus atributos.
     *
     * @return Uma String que representa o Médico.
     */
    @Override
    public String toString() {
        return super.toString() + ", Especialidade: " + especialidade;
    }
}
