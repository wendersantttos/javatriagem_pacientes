/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pessoa;

/**
 * Classe que representa um Administrador, que é um tipo de Colaborador.
 * Herda os atributos e métodos da classe Colaborador.
 */
public class Administrador extends Colaborador {

    /**
     * Construtor da classe Administrador.
     * 
     * @param id       O ID do administrador.
     * @param nome     O nome do administrador.
     * @param cargo    O cargo do administrador.
     * @param email    O email do administrador.
     * @param telefone O telefone do administrador.
     */
    public Administrador(int id, String nome, String cargo, String email, String telefone) {
        super(id, nome, cargo, email, telefone);
    }

    /**
     * Retorna uma representação em string do objeto Administrador.
     *
     * @return Uma string representando o objeto Administrador.
     */
    @Override
    public String toString() {
        return "Administrador{" + '}';
    }
}
