/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pessoa;

/**
 * Classe abstrata que representa um Colaborador no sistema.
 * Contém os atributos e métodos comuns a todos os colaboradores.
 */
public class Colaborador {

    private int id;
    private String nome;
    private String cargo;
    private String email;
    private String telefone;

    /**
     * Construtor que inicializa um Colaborador com todos os atributos.
     *
     * @param id       O ID do Colaborador.
     * @param nome     O nome do Colaborador.
     * @param cargo    O cargo do Colaborador.
     * @param email    O email do Colaborador.
     * @param telefone O telefone do Colaborador.
     */
    public Colaborador(int id, String nome, String cargo, String email, String telefone) {
        this.id = id;
        this.nome = nome;
        this.cargo = cargo;
        this.email = email;
        this.telefone = telefone;
    }

    /**
     * Construtor que inicializa um Colaborador com nome e cargo.
     *
     * @param nome  O nome do Colaborador.
     * @param cargo O cargo do Colaborador.
     */
    public Colaborador(String nome, String cargo) {
        this.nome = nome;
        this.cargo = cargo;
    }

    /**
     * Método construtor vazio não utilizado. Lança uma exceção se chamado.
     *
     * @throws UnsupportedOperationException Sempre lança essa exceção.
     */
    public Colaborador() {
        throw new UnsupportedOperationException("Método não suportado.");
    }

    // Getters e Setters (não é necessário documentar os getters e setters JavaDoc)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Nome: " + nome + ", Cargo: " + cargo + ", Email: " + email + ", Telefone: " + telefone;
    }
}
