package Pessoa;

/**
 * Classe que representa um Enfermeiro, que é um tipo de Colaborador.
 * Herda os atributos e métodos da classe Colaborador.
 */
public class Enfermeiro extends Colaborador {

    private String setor;

    /**
     * Construtor que inicializa um Enfermeiro com todos os atributos.
     *
     * @param id       O ID do Enfermeiro.
     * @param nome     O nome do Enfermeiro.
     * @param cargo    O cargo do Enfermeiro.
     * @param email    O email do Enfermeiro.
     * @param telefone O telefone do Enfermeiro.
     * @param setor    O setor em que o Enfermeiro trabalha.
     */
    public Enfermeiro(int id, String nome, String cargo, String email, String telefone, String setor) {
        super(id, nome, cargo, email, telefone);
        this.setor = setor;
    }

    /**
     * Obtém o setor em que o Enfermeiro trabalha.
     *
     * @return O setor do Enfermeiro.
     */
    public String getSetor() {
        return setor;
    }

    /**
     * Define o setor em que o Enfermeiro trabalha.
     *
     * @param setor O setor do Enfermeiro.
     */
    public void setSetor(String setor) {
        this.setor = setor;
    }

    /**
     * Retorna uma representação em String dos atributos do Enfermeiro.
     *
     * @return Uma String com os atributos do Enfermeiro.
     */
    @Override
    public String toString() {
        return super.toString() + ", Setor: " + setor;
    }
}
